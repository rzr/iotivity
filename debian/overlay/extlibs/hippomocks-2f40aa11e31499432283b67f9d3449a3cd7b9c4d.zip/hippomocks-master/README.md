Hippomocks
==========

Single-header mocking framework.

